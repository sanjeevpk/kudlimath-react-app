import React from 'react';
import Navigation from './navigation';
import Heading from './heading';
import Footer from './footer';
import { 
    CardGroup, 
    Row, 
    Card, 
    CardBody, 
    CardText, 
    CardTitle, 
    Button, 
    Col, 
    CardHeader 
} from 'reactstrap';
import PeopleIcon from '@mui/icons-material/People';
import AutoStoriesIcon from '@mui/icons-material/AutoStories';
import PetsIcon from '@mui/icons-material/Pets';
import RecordVoiceOverIcon from '@mui/icons-material/RecordVoiceOver';
import HomeOrigin from '../images/home_origin.png';
import NewspaperIcon from '@mui/icons-material/Newspaper';

function News(){
    return (
        <div>
            <Navigation/>
            <Heading/>
            <hr/>
            <h2 style={{textAlign:'center'}}>News</h2>          
            <Row>
                <Col sm="4" style={{paddingLeft:10}}>
                    <Card className="my-2" color="warning" outline> 
                        <CardHeader style={{fontWeight:'bold'}}>
                                <NewspaperIcon style={{textAlign:'left'}}/>
                                <span style={{textAlign:'center'}}> Arogya Vijaya</span>
                            </CardHeader> 
                        <CardBody className="my-2" color="warning">      
                            <img className='rounded'
                                alt="Card cap"
                                src="https://scontent.fblr4-2.fna.fbcdn.net/v/t39.30808-6/366373267_654013283494158_176068449665562242_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=5614bc&_nc_ohc=r-vL1BqR65oAX8lfDKD&_nc_ht=scontent.fblr4-2.fna&oh=00_AfCEwkHboVsp4FYnoBttH-g_sDTINeJhC8yobREEfEPp8g&oe=65039242"
                                style={{height:'250px', width:'350px'}}
                            />          
                            <CardText style={{paddingTop:5}}>
                            <p>
                                On the occasion of 21st Charturmasa, we are conducting free health checkup camps,
                                we encourage followers to make use of such benefits.
                            </p>
                            </CardText>
                        </CardBody>
                    </Card>
                </Col>
                <Col sm="4">
                    <Card className="my-2" color="warning" outline> 
                        <CardHeader style={{fontWeight:'bold'}}>
                                <NewspaperIcon style={{textAlign:'left'}}/>
                                <span style={{textAlign:'center'}}> Sangeet Utsava</span>
                            </CardHeader> 
                        <CardBody className="my-2" color="warning">      
                            <img className='rounded'
                                alt="Card cap"
                                src="https://scontent.fblr4-2.fna.fbcdn.net/v/t39.30808-6/366942412_654010903494396_7258833728653846883_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=5614bc&_nc_ohc=9J7yNJkN9oYAX_rLu0u&_nc_ht=scontent.fblr4-2.fna&oh=00_AfCKcPQsKDR4QD-N6dtPQnrz32wMpBt27w2B9gLrllB97w&oe=6503BD29"
                                style={{height:'250px', width:'350px'}}
                            />          
                            <CardText style={{paddingTop:5}}>
                            <p>
                                On the occasion of 21st Charturmasa, Sangeeta Utsava is been conducted. 
                                Bhakti pradana songs will be sung by Shiraksha Mundagod 
                            </p>
                            </CardText>
                        </CardBody>
                    </Card>
                </Col>
                <Col sm="4">
                    <Card className="my-2" color="warning" outline> 
                        <CardHeader style={{fontWeight:'bold'}}>
                                <NewspaperIcon style={{textAlign:'left'}}/>
                                <span style={{textAlign:'center'}}> Sangeet Utsava</span>
                            </CardHeader> 
                        <CardBody className="my-2" color="warning">      
                            <img className='rounded'
                                alt="Card cap"
                                src="https://scontent.fblr4-2.fna.fbcdn.net/v/t39.30808-6/363007674_646363257592494_2642640479839974569_n.jpg?_nc_cat=105&ccb=1-7&_nc_sid=5614bc&_nc_ohc=tLv03Id-FiYAX9PjOuy&_nc_ht=scontent.fblr4-2.fna&oh=00_AfC0ENG5Q5rq1lVrPcftAgMUYIOQjq732gKx7XNnI-ZwUQ&oe=65030C53"
                                style={{height:'250px', width:'350px'}}
                            />          
                            <CardText style={{paddingTop:5}}>
                            <p>
                                On the occasion of 21st Charturmasa, Sangeeta Utsava is been conducted. 
                                Bhakti pradana songs will be sung by Sameer Ghambir
                            </p>
                            </CardText>
                        </CardBody>
                    </Card>
                </Col>
                <Col sm="4">
                    <Card className="my-2" color="warning" outline> 
                        <CardHeader style={{fontWeight:'bold'}}>
                                <NewspaperIcon style={{textAlign:'left'}}/>
                                <span style={{textAlign:'center'}}> Anugraha Sandesha</span>
                            </CardHeader> 
                        <CardBody className="my-2" color="warning">      
                            <img className='rounded'
                                alt="Card cap"
                                src="https://scontent.fblr4-5.fna.fbcdn.net/v/t39.30808-6/361884703_635710431991110_8288650643880765410_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5614bc&_nc_ohc=MX9NCoZYMmcAX_z2zX8&_nc_ht=scontent.fblr4-5.fna&oh=00_AfCXi9A_dYizhXvIIvxb5-SkePygBJlH9iWY4gR7Lexyfw&oe=6502DD9E"
                                style={{height:'250px', width:'350px'}}
                            />          
                            <CardText style={{paddingTop:5}}>
                            <p>
                                On the occasion of 21st Charturmasa, augraha sandesha from 
                                Shree Raghu Vijaya Teerth Swamiji on Shree Maha Bharat Tatparya Nirnaya 
                            </p>
                            </CardText>
                        </CardBody>
                    </Card>
                </Col>
                <Col sm="4">
                    <Card className="my-2" color="warning" outline>
                        <CardHeader style={{fontWeight:'bold'}}>
                                <NewspaperIcon style={{textAlign:'left'}}/>
                                <span style={{textAlign:'center'}}> Chaturmasa Sankalpa</span>
                            </CardHeader> 
                        <CardBody className="my-2" color="warning">      
                            <img className='rounded'
                                alt="Card cap"
                                src="https://scontent.fblr4-3.fna.fbcdn.net/v/t39.30808-6/355479344_619583063603847_6779038651601740580_n.jpg?_nc_cat=108&ccb=1-7&_nc_sid=5614bc&_nc_ohc=EQzOoQNmtnwAX9cvxYX&_nc_ht=scontent.fblr4-3.fna&oh=00_AfBxk-cgljMoaRf2FdJuOCJJkNvEKchCNvRaOWxa3i20Ig&oe=6503A053"
                                style={{height:'250px', width:'350px'}}
                            />          
                            <CardText style={{paddingTop:5}}>
                            <p>
                                21st Chaturmasa Invitation 
                            </p>
                            </CardText>
                        </CardBody>
                    </Card>
                </Col>
                <Col sm="4">
                    <Card className="my-2" color="warning" outline> 
                        <CardHeader style={{fontWeight:'bold'}}>
                                <NewspaperIcon style={{textAlign:'left'}}/>
                                <span style={{textAlign:'center'}}> Mahasamaradhane</span>
                            </CardHeader> 
                        <CardBody className="my-2" color="warning">      
                            <img className='rounded'
                                alt="Card cap"
                                src="https://scontent.fblr4-1.fna.fbcdn.net/v/t39.30808-6/318960152_453514450303852_1336204251401373223_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=5614bc&_nc_ohc=rFdSs1JL60cAX8pdC_v&_nc_ht=scontent.fblr4-1.fna&oh=00_AfByAooX-rxYqVSJrjLHZnFdt93npt25sDSYMTnBjw1BIw&oe=6502F5EE"
                                style={{height:'250px', width:'350px'}}
                            />          
                            <CardText style={{paddingTop:5}}>
                            <p>
                                Shree 1008 Shree Raghupriya Teertha swamiji's 15th Mahasamaradhane invite.
                            </p>
                            </CardText>
                        </CardBody>
                    </Card>
                </Col>
            </Row>
        <Footer/>
    </div>
    );
}

export default News;