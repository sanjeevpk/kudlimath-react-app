// import React, {useState, createContext, useContext} from "react";

// export const DonatePageContext = createContext();

// export const DonatePageProvider = ({children}) => {

//     const [donateDetailsPage, setDonateDetailsPage] = useState("");

//     return(
//         <DonatePageContext.Provider value={[donateDetailsPage, setDonateDetailsPage]}>
//             {children}
//         </DonatePageContext.Provider>
//     )

// };